const toggle = document.getElementById("toggleExtension");
const notifToggle = document.getElementById("toggleNotifications");
const statusBadge = document.getElementById("statusBadge");

// Load saved states
chrome.storage.local.get(["enabled", "notificationsEnabled"], (result) => {
  const enabled = result.enabled ?? true;
  const notificationsEnabled = result.notificationsEnabled ?? false;

  toggle.checked = enabled;
  notifToggle.checked = notificationsEnabled;
  updateBadge(enabled);
});

function updateBadge(enabled) {
  statusBadge.textContent = enabled ? "Active" : "Paused";
  statusBadge.className = "tf-status-badge" + (enabled ? "" : " off");
}

// Handle Extension ON/OFF toggle
toggle.addEventListener("change", () => {
  const enabled = toggle.checked;
  chrome.storage.local.set({ enabled }, () => {
    updateBadge(enabled);
  });

  if (!enabled) return;

  // Scan for duplicates when turned ON
  chrome.runtime.sendMessage({ action: "scanDuplicates" });
});

// Handle Notifications ON/OFF toggle
notifToggle.addEventListener("change", () => {
  const notificationsEnabled = notifToggle.checked;
  chrome.storage.local.set({ notificationsEnabled });
});