const closedByExtension = new Set();

function notifyUser(title, message) {
  chrome.storage.local.get("notificationsEnabled", (result) => {
    if (result.notificationsEnabled) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "assets/icon.png",
        title: title,
        message: message
      });
    }
  });
}

// Set defaults on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["enabled", "notificationsEnabled"], (result) => {
    const defaults = {};
    if (result.enabled === undefined) defaults.enabled = true;
    if (result.notificationsEnabled === undefined) defaults.notificationsEnabled = false;
    chrome.storage.local.set(defaults);
  });
});

// Handle new/updated tabs
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!tab.url || !tab.url.startsWith("http")) return;
  if (closedByExtension.has(tabId)) return;

  chrome.storage.local.get("enabled", (result) => {
    if (!result.enabled) return;

    chrome.tabs.query({}, (tabs) => {
      for (let otherTab of tabs) {
        if (otherTab.id === tabId) continue;
        if (otherTab.url !== tab.url) continue;

        // Focus the existing (older) tab
        chrome.tabs.update(otherTab.id, { active: true });
        chrome.windows.update(otherTab.windowId, { focused: true });

        // Close the duplicate
        closedByExtension.add(tabId);
        chrome.tabs.remove(tabId);

        notifyUser(
          "Duplicate tab closed",
          "An existing tab was already open, so the duplicate was closed."
        );

        break;
      }
    });
  });
});

// Handle scanDuplicates message from popup
chrome.runtime.onMessage.addListener((message) => {
  if (message.action !== "scanDuplicates") return;

  chrome.storage.local.get("enabled", (result) => {
    if (!result.enabled) return;

    chrome.tabs.query({}, (tabs) => {
      const seenUrls = new Map();
      let duplicatesClosed = 0;
      let originalTab = null;

      for (let tab of tabs) {
        if (!tab.url || !tab.url.startsWith("http")) continue;

        if (seenUrls.has(tab.url)) {
          if (!originalTab) originalTab = seenUrls.get(tab.url);
          closedByExtension.add(tab.id);
          chrome.tabs.remove(tab.id);
          duplicatesClosed++;
        } else {
          seenUrls.set(tab.url, tab);
        }
      }

      if (originalTab) {
        chrome.tabs.update(originalTab.id, { active: true });
        chrome.windows.update(originalTab.windowId, { focused: true });
      }

      if (duplicatesClosed > 0) {
        notifyUser(
          "Duplicate tabs closed",
          `${duplicatesClosed} duplicate tab${duplicatesClosed > 1 ? "s" : ""} were closed.`
        );
      }
    });
  });
});

chrome.tabs.onRemoved.addListener((removedTabId) => {
  closedByExtension.delete(removedTabId);
});